How to Contribute
=================

Pull Requests
-------------

1. Pull requests are welcome.
2. Make sure to pass the unit tests. Write unit tests for new modules if
needed.
