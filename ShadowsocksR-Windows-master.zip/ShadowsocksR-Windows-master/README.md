<img src="shadowsocks-csharp/Resources/ssw128.png" width="48"/>ShadowsocksR for Windows
=======================

[![](https://img.shields.io/badge/Telegram-Channel-blue)](https://t.me/ShadowsocksR_Windows)
[![](https://img.shields.io/badge/Telegram-Group-green)](https://t.me/joinchat/Gn-Aa0-j4Hdthl502zlIlQ)

## Build

[![](https://github.com/HMBSbige/ShadowsocksR-Windows/workflows/GitHub%20CI/badge.svg)](https://github.com/HMBSbige/ShadowsocksR-Windows/actions)

## [Wiki](https://github.com/HMBSbige/ShadowsocksR-Windows/wiki)

## 相关推荐

[**壁虎翻墙网 :100:**](https://geckoiplc.com/register?aff=z9dkkpHM)

这是我所选择的服务器提供商，IPLC专线翻墙、稳定、速度快、价格便宜。欢迎大家使用我的推广链接前去注册。https://geckoiplc.com/register?aff=z9dkkpHM

## Download

* [latest release]

## Donate
[Donate](./pic/wechat.jpg)

## Develop

Visual Studio Community 2019 is recommended.

## License

GPLv3

Copyright © HMBSbige 2019 - 2020. Forked from ShadowsocksR by BreakWa11

[latest release]: https://github.com/HMBSbige/ShadowsocksR-Windows/releases
