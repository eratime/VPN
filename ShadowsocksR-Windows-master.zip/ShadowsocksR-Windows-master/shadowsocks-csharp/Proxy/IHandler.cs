﻿namespace Shadowsocks.Proxy
{
    public abstract class IHandler
    {
        public abstract void Shutdown();
    }
}
