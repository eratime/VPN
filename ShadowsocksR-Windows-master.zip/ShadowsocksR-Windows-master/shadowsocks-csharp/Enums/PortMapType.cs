﻿namespace Shadowsocks.Enums
{
    public enum PortMapType
    {
        Forward = 0,
        ForceProxy,
        RuleProxy
    }
}