﻿namespace Shadowsocks.Enums
{
    public enum HttpRequestProxyType
    {
        Auto,
        Direct,
        Proxy,
        SystemSetting
    }
}
