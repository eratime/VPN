﻿namespace Shadowsocks.Enums
{
    public enum ProxyMode
    {
        NoModify,
        Direct,
        Pac,
        Global
    }
}