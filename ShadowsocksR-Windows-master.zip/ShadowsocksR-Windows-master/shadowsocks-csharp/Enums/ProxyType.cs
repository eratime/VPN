﻿namespace Shadowsocks.Enums
{
    public enum ProxyType
    {
        Socks5,
        Http,
        TcpPortTunnel
    }
}
