﻿namespace Shadowsocks.Enums
{
    public enum ServerTreeViewType
    {
        Subtag,
        Group,
        Server
    }
}
