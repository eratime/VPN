﻿namespace Shadowsocks.Enums
{
    public enum DnsType
    {
        Default,
        DnsOverTls
    }
}
