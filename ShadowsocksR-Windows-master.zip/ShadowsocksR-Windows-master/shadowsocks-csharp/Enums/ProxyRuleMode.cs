﻿namespace Shadowsocks.Enums
{
    public enum ProxyRuleMode
    {
        Disable = 0,
        BypassLan,
        BypassLanAndChina,
        BypassLanAndNotChina,
        UserCustom = 16
    }
}