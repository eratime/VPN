﻿namespace Shadowsocks.Enums
{
    public enum PacType
    {
        GfwList,
        Online,
    }
}
