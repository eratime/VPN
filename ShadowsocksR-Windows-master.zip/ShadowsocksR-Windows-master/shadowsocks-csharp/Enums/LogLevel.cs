﻿namespace Shadowsocks.Enums
{
    public enum LogLevel
    {
        Debug = 0,
        Info,
        Warn,
        Error,
        Assert
    }
}