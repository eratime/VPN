﻿namespace Shadowsocks.Util
{
    internal static class Constants
    {
        public const string ParameterSetAutoRun = @"-setautorun";
        public const string ParameterMultiplyInstance = @"-show";
    }
}
