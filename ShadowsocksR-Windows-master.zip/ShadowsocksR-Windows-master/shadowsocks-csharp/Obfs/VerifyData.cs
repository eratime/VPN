﻿namespace Shadowsocks.Obfs
{
    public class VerifyData
    {
    }
}
