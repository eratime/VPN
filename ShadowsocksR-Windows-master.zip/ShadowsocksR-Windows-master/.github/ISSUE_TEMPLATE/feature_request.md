---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: Enhancement
assignees: ''

---

**您的功能请求是否与 BUG 有关？ 请描述一下。**

简明扼要地描述了问题所在

**描述您想要的解决方案**

简明扼要地描述您想要发生的事情

**描述您考虑过的替代方案**

对您考虑的任何替代解决方案或功能的简明扼要描述

**其它内容**

在此处添加有关功能请求的任何其它内容或屏幕截图
